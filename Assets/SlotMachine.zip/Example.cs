﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{

    public SlotMachineBaseGrid slotMachine;

    // Start is called before the first frame update
    void Start()
    {
        /* 인자별 설명 */
        //아이템은 1,2,3,4가 리스트로 들어갔음,
        //1,2,3,4중에 배열 1번째 선택
        //슬롯머신을 3초동안 재생(완벽히 정확한 3초는 아니지만 차이는 별로 없음. (3.0~3.3초))
        slotMachine.StartSlotMachine(new List<int>() { 1, 2, 3, 4 }, 1, 3);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
