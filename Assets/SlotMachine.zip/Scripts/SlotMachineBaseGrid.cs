﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SlotMachineBaseGrid : MonoBehaviour
{

    public GameObject ItemPrefab;

    private List<SlotMachineItem> slotItemList = new List<SlotMachineItem>();
    public List<SlotMachineItem> SlotItemList { get => this.slotItemList; set => this.slotItemList = value; }

    /// <summary>
    /// Item Height Size, 표현하고자 하는 슬롯머신 아이템 RectTransform의 Height값으로 설정.
    /// </summary>
    public float itemHeightUnit;
    /// <summary>
    /// 이미지에 Margin 값이 있을경우 입력. (테스트 안됨.)
    /// </summary>
    public float itemHeightMargin;
    private float ItemHeight => itemHeightMargin + itemHeightUnit;
    private float AccumulateMovedHeight { get; set; }
    private float TargetMoveHeight { get; set; }

    /// <summary>
    /// LerpSpeed, 수정시 슬롯머신의 회전속도 빨라짐.
    /// </summary> 
    public float LerpSpeed = 0.25f; 
    private float RemainTime = 5f;

    private bool isSelected = false;


    /* 서버 데이터 (SelectedItemIndex), Zone4 Struct로 바꿔서 사용하세요. */
    private int SelectedItemArray = 2;
    private SlotMachineItem SelectedItemObject = null;
    /* 여기선 사용안함. Zone4 Struct로 바꿔서 사용하세요. */
    /* 최종 결과물에 대한 정보등을 표기하기 위한 인덱스(없어도 됨) */
    [HideInInspector]
    public int SelectedItemIndex = -1; 
    private float latest_half_height = 0;
    private float subLerpValue = 0.0f;
    private int remainCount = 0;
    private bool isTimeEnded = false; //시간이 0이되는경우 
    private bool isSelectMode = false; //셀렉트모드로 변경(픽되는 순간)
    private int stackedRotateCount = 0;
    private bool isRunning = false;
    public bool StartSlotMachine(List<int> Items, int SelectedArrayIndex, int Time = 3)
    {
        /* Running Failed! */
        if(isRunning)
        {
            return false;
        }

        RemainTime = Time;
        ///더미데이터 초기화
        Initstallize();
        ///아이템 인덱스 1,2,3,4를 서버로부터 받았음.
        AddItems(Items);
        ///슬롯머신 스타트.
        StartCoroutine(RunSlotMachine(Time, LerpSpeed, SelectedArrayIndex));

        /* Running Succesfully! */
        return true;
    }

    private int RemainCount
    {
        get
        {
            return (SelectedItemObject.ItemOriginalArrayIndex < SelectedItemArray) ? SelectedItemArray - SelectedItemObject.ItemOriginalArrayIndex : SlotItemList.Count - (SelectedItemObject.ItemOriginalArrayIndex - SelectedItemArray);
        }
    }
    private void Awake()
    {
      
    }
     
    /// <summary>
    /// 새로운 슬롯머신 사용이 있을경우, 해당 함수를 한번 호출해서 더미데이터와 데이터들을 초기화 해줘야함.
    /// </summary>
    void Initstallize()
    {
        Clear();
    
        TargetMoveHeight = 0;
        AccumulateMovedHeight = 0;
        latest_half_height = 0;
        subLerpValue = 0.0f;    
        remainCount = 0;
        isSelected = false;
        isSelectMode = false;
        isTimeEnded = false;
        SelectedItemObject = null;
        SelectedItemIndex = 0;
        stackedRotateCount = 0;
        SelectedItemArray = 0; 
        this.transform.localPosition = new Vector3(0, 0, 0); 
    }
    /// <summary>
    /// 슬롯머신에 아이템 등록. 
    /// </summary>
    /// <param name="itemList"></param>
    private void AddItems(List<int> itemList)
    {
        for (int i = 0; i < itemList.Count; i++)
        {
            var data = Instantiate(ItemPrefab);
            data.name = $"Item_{i}";
            data.transform.SetParent(this.transform, false);
            var rt = data.transform as RectTransform;
            rt.anchoredPosition = new Vector3(0, -(i * ItemHeight), 0); 
            var smItem = data.GetComponent<SlotMachineItem>();
            SlotItemList.Add(smItem);
            smItem.ItemOriginalArrayIndex = i;
            smItem.ItemIndex = (uint)itemList[i];
        }
    }


    private void RotateSlot(float speed)
    {
        /// 속력감소
        void SubSpeed()
        {
            float target_speed = speed * 0.5f;
            subLerpValue = Mathf.Lerp(subLerpValue, target_speed, 1f * Time.deltaTime); 
        }
        ///슬롯머신 회전
        void DefaultRotate()
        {
            var originY = this.transform.localPosition.y;
            this.transform.localPosition = Vector3.Lerp(this.transform.localPosition, new Vector3(0, TargetMoveHeight, 0), subLerpValue);
            var updatedY = this.transform.localPosition.y;
            AccumulateMovedHeight += updatedY - originY;
        }
        //시간이 2
        void CountBaseRotate()
        {
            if (remainCount != 0)
            {
                var originY = this.transform.localPosition.y;
                this.transform.localPosition = Vector3.Lerp(this.transform.localPosition, new Vector3(0, TargetMoveHeight, 0), subLerpValue);
                var updatedY = this.transform.localPosition.y;
                AccumulateMovedHeight += updatedY - originY;
            }
            else
            { 
                if(remainCount == 0 && isTimeEnded && latest_half_height == 0)
                {
                    latest_half_height = this.transform.localPosition.y + ItemHeight / 2; 
                } 

                if (latest_half_height - (this.transform.localPosition.y) > 0.1f && isSelectMode == false)
                { 
                    this.transform.localPosition = Vector3.Lerp(this.transform.localPosition, new Vector3(0, latest_half_height, 0), 0.15f);
                }
                else
                {
                    isSelectMode = true; 
                    this.transform.localPosition = Vector3.Lerp(this.transform.localPosition, new Vector3(0, stackedRotateCount * ItemHeight, 0), 0.15f);

                    var p = stackedRotateCount * ItemHeight;
                    var m = this.transform.localPosition.y;
                    if (p - m > -.1f && p - m < .1f)
                    {
                        isSelected = true;
                    }
                }
            }
        } 
        void Swap()
        {
            
            var latestItemPos = (SlotItemList[SlotItemList.Count - 1].transform as RectTransform).anchoredPosition;
            var currentItemRect = (SlotItemList[0].transform as RectTransform);
            currentItemRect.anchoredPosition = latestItemPos - new Vector2(0, ItemHeight);

            /* Move-Distance Check */
            AccumulateMovedHeight = (AccumulateMovedHeight - ItemHeight);

            /* Swap처리 */
            var prevItem = slotItemList[0];
            for (int i = 1; i < SlotItemList.Count; i++)
                SlotItemList[i - 1] = SlotItemList[i];
            SlotItemList[SlotItemList.Count - 1] = prevItem;
            TargetMoveHeight = this.transform.localPosition.y + ItemHeight; 
            SelectedItemObject = SlotItemList[0];

            
        }

        if (RemainTime > 0)
        {
            DefaultRotate();
        } 
        else /*2초 미만으로 떨어질시 속력감소부분*/
        {
            if (isTimeEnded == false)
            {
                remainCount = RemainCount; 
            }
            isTimeEnded = true;
            SubSpeed();
            CountBaseRotate(); 
        }

        if (AccumulateMovedHeight >= ItemHeight)
        {
            if(isTimeEnded)
               remainCount -= 1;
            stackedRotateCount++;
            Swap();
        }
    }
    private IEnumerator RunSlotMachine(float time, float speed, int selectedArray)
    {
        isRunning = true;
        this.SelectedItemArray = selectedArray;
        subLerpValue = speed;
        SelectedItemObject = SlotItemList[SelectedItemIndex];
        while (time > 0 || isSelected == false)
        { 
             
            TargetMoveHeight = this.transform.localPosition.y + ItemHeight;
            RotateSlot(speed);
            time -= Time.deltaTime;
            RemainTime = time;

             
            yield return null;
        } 
        isRunning = false; 
    }

    private void Clear()
    {
        for(int i = 0; i<slotItemList.Count; i++)
        {
            Destroy(slotItemList[i].gameObject);
        }

        slotItemList.Clear();
    }
}
