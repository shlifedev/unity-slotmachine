﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{ 
    public SlotMachine slotMachine;  
    // Start is called before the first frame update
    void Start()
    {
        var list = new List<int>() { 1, 2, 3 };
        if(slotMachine!=null)
            slotMachine.StartSlotMachine(list, 2);
    }

    // Update is called once per frame
    void Update()
    {

    }
}
